package BCS345;

import java.util.Date;

public class Transaction {

	/**
	 * Amount of this transaction/
	 */
	private double amount;
	
	/**
	 * The time and date of this transaction.
	 */
	private Date timestamp;
	
	/**
	 * Memo for the transaction.
	 */
	private String memo;
	
	/**
	 * Account transaction was performed in.  
	 */
	private Account inAccount;
	
	/**
	 * Create a new transaction
	 * @parameter amount the amount transacted 
	 * @parameter inAccount the amount the transaction belongs to 
	 */
	public Transaction(double amount, Account inAccount) {
		
		this.amount = amount;
		this.inAccount = inAccount;
		this.timestamp = new Date();
		this.memo = "";
		
	}
	
	/**
	 * Create a new transaction
	 * @parameter amount the amount transacted 
	 * @parameter inAccount the amount the transaction` belongs to 
	 */
	public Transaction(double amount, String memo, Account inAccount) {
		
		//First Call the two-arg constructor 
		this(amount, inAccount);
		
		//Set memo 
		this.memo = memo;
		
	}
	
	/**
	 * Get the amount of the transaction
	 * @return the amount
	 */
	public double getAmount() {
		return this.amount;	
	}
	
	/**
	 * Get a string summarizing the transaction 
	 * @return the amount
	 */
	public String getSummaryLine() {
		
		if (this.amount >=0) {
			return String.format("%s : $%.02f : %s", this.timestamp.toString(),
					this.amount, this.memo);
		} else {
			return String.format("%s : $(%.02f) : %s", this.timestamp.toString(), 
					-this.amount, this.memo);
		}
	}
}
