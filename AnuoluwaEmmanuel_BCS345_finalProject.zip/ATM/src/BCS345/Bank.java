package BCS345;

import java.util.ArrayList;
import java.util.Random;
public class Bank {

	private String name; 
	
	private ArrayList<Customers> customers;
	
	private ArrayList<Account> accounts;
	
	/**
	 * Create a new bank object with empty lists of customers and accounts 
	 * @parameter name the name of the Bank
	 */
	public Bank(String name) {
		
		this.name = name; 
		this.customers = new ArrayList<Customers>();
		this.accounts =new ArrayList<Account>();
	}
	
	/**
	 * Generate a new universally unique ID for a customer.
	 * @return the uuid
	 */
	public String getNewUserUUID() {
		
		//Initialize 
		String uuid;
		Random rng = new Random();
		int len = 5;
		boolean nonUnique ;
		
		// Continue looping till we get Unique ID
		do {
			
			//Generate number 
			uuid = "";
			for (int c = 0; c < len; c++) {
				uuid += ((Integer)rng.nextInt(10)).toString();
		}
		
		// check to confirm it's unique 
			nonUnique = false;
			for (Customers c : this.customers) {
			if (uuid.compareTo(c.getUUID()) == 0) {
				nonUnique = true;
				break;
			}
		}
			
		} while (nonUnique);
			return uuid;
	}
	
	/** 
	 * Generate a new universally unique ID for an account
	 * @return the uuid
	 */
	public String getNewAccountUUID() {
		
		//Initialize 
		String uuid;
		Random rng = new Random();
		int len = 5;
		boolean nonUnique ;
		
		// Continue looping till we get Unique ID
		do {
			
			//Generate number 
			uuid = "";
			for (int c = 0; c < len; c++) {
				uuid += ((Integer)rng.nextInt(10)).toString();
		}
		
		// check to confirm it's unique 
			nonUnique = false;
			for (Account a : this.accounts) {
			if (uuid.compareTo(a.getUUID()) == 0) {
				nonUnique = true;
				break;
			}
		}
			
		} while (nonUnique);
		
		return uuid;

	}
		/**
		 * Add an account 
		 * @parameter anAcct the account to add 
		 */
	public void addAccount(Account anAcct) {
		this.accounts.add(anAcct);
	}
	
		/**
		 * Create a new customer of the bank
		 * @parameter firstName the customers  first name
		 * @parameter lastName the customers  last name
		 * @parameter pin the customers  pin 
		 * @return the new customers object 
		 */
		public Customers addCustomers(String firstName, String lastName, String pin) {
			
			//Create a new user object and add it to the list
			Customers newCustomer = new Customers(firstName, lastName, pin, this);
			this.customers.add(newCustomer);
			
			//create a savings account for the customer and to add to Customer and bank accounts list
			Account newAccount = new Account("Savings", newCustomer, this);
			newCustomer.addAccount(newAccount);
			this.addAccount(newAccount);
			
			return newCustomer;
			
		}
		
		/**
		 * Get the Customer object associated with a particular customer with a particular customerID
		 * @parameter customerID
		 * @parameter pin
		 * @return
		 */
		public Customers customerLogin(String customerID, String pin) {
			
			// Search thru the list of users 
			for (Customers c : this.customers) {
				
				// Check if the customer  ID is correct 
				if (c.getUUID().compareTo(customerID) == 0 && c.validatePin(pin)) {
					return c;
				}
			}
			
			// If the customer hasn't been found or incorrect pin 
			return null; 
		}
		/**
		 * Get the name of the bank
		 * @return the name of the bank
		 */
		public String getName() {
			return this.name;
		
	}

	
	}